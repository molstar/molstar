Tree schema:
  - root
    [Root of the tree must be of this kind]
    Auxiliary node kind that only appears as the tree root.
    Parent: none
    Params:
  - download
    This node instructs to retrieve a data resource.
    Parent: root
    Params:
      - url: string
        URL of the data resource.
  - parse
    This node instructs to parse a data resource.
    Parent: download
    Params:
      - format: "mmcif" | "bcif" | "pdb" | "map"
        Format of the input data resource.
  - structure
    This node instructs to create a structure from a parsed data resource. "Structure" refers to an internal representation of molecular coordinates without any visual representation.
    Parent: parse
    Params:
      - type: "model" | "assembly" | "symmetry" | "symmetry_mates"
        Type of structure to be created (`"model"` for original model coordinates, `"assembly"` for assembly structure, `"symmetry"` for a set of crystal unit cells based on Miller indices, `"symmetry_mates"` for a set of asymmetric units within a radius from the original model).
      - block_header?: string | null
        Header of the CIF block to read coordinates from (only applies when the input data are from CIF or BinaryCIF). If `null`, block is selected based on `block_index`.
        Default: null
      - block_index?: Integer
        0-based index of the CIF block to read coordinates from (only applies when the input data are from CIF or BinaryCIF and `block_header` is `null`).
        Default: 0
      - model_index?: Integer
        0-based index of model in case the input data contain multiple models.
        Default: 0
      - assembly_id?: string | null
        Assembly identifier (only applies when `kind` is `"assembly"`). If `null`, the first assembly is selected.
        Default: null
      - radius?: number
        Distance (in Angstroms) from the original model in which asymmetric units should be included (only applies when `kind` is `"symmetry_mates"`).
        Default: 5
      - ijk_min?: [Integer, Integer, Integer]
        Miller indices of the bottom-left unit cell to be included (only applies when `kind` is `"symmetry"`).
        Default: [-1, -1, -1]
      - ijk_max?: [Integer, Integer, Integer]
        Miller indices of the top-right unit cell to be included (only applies when `kind` is `"symmetry"`).
        Default: [1, 1, 1]
  - transform
    This node instructs to rotate and/or translate structure coordinates.
    Parent: structure
    Params:
      - rotation?: Array<number>
        Rotation matrix (3x3 matrix flattened in column major format (j*3+i indexing), this is equivalent to Fortran-order in numpy). This matrix will multiply the structure coordinates from the left. The default value is the identity matrix (corresponds to no rotation).
        Default: [1, 0, 0, 0, 1, 0, 0, 0, 1]
      - translation?: [number, number, number]
        Translation vector, applied to the structure coordinates after rotation. The default value is the zero vector (corresponds to no translation).
        Default: [0, 0, 0]
  - component
    This node instructs to create a component (i.e. a subset of the parent structure).
    Parent: structure
    Params:
      - selector: ("all" | "polymer" | "protein" | "nucleic" | "branched" | "ligand" | "ion" | "water" | "coarse") | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }>
        Defines what part of the parent structure should be included in this component.
  - component_from_uri
    This node instructs to create a component defined by an external annotation resource.
    Parent: structure
    Params:
      - uri: string
        URL of the annotation resource.
      - format: "cif" | "bcif" | "json"
        Format of the annotation resource.
      - schema: "whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"
        Annotation schema defines what fields in the annotation will be taken into account.
      - block_header?: string | null
        Header of the CIF block to read annotation from (only applies when `format` is `"cif"` or `"bcif"`). If `null`, block is selected based on `block_index`.
        Default: null
      - block_index?: Integer
        0-based index of the CIF block to read annotation from (only applies when `format` is `"cif"` or `"bcif"` and `block_header` is `null`).
        Default: 0
      - category_name?: string | null
        Name of the CIF category to read annotation from (only applies when `format` is `"cif"` or `"bcif"`). If `null`, the first category in the block is used.
        Default: null
      - field_name?: string
        Name of the column in CIF or field name (key) in JSON that contains the component identifier.
        Default: "component"
      - field_remapping?: { [K in string]: (string | null) }
        Optional remapping of annotation field names `{ standardName1: actualName1, ... }`. Use `{ "label_asym_id": "X" }` to load actual field "X" as "label_asym_id". Use `{ "label_asym_id": null }` to ignore actual field "label_asym_id". Fields not mentioned here are mapped implicitely (i.e. actual name = standard name).
        Default: {}
      - field_values?: Array<string> | null
        List of component identifiers (i.e. values in the field given by `field_name`) which should be included in this component. If `null`, component identifiers are ignored (all annotation rows are included), and `field_name` field can be dropped from the annotation.
        Default: null
  - component_from_source
    This node instructs to create a component defined by an annotation resource included in the same file this structure was loaded from. Only applicable if the structure was loaded from an mmCIF or BinaryCIF file.
    Parent: structure
    Params:
      - schema: "whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"
        Annotation schema defines what fields in the annotation will be taken into account.
      - block_header?: string | null
        Header of the CIF block to read annotation from. If `null`, block is selected based on `block_index`.
        Default: null
      - block_index?: Integer
        0-based index of the CIF block to read annotation from (only applies when `block_header` is `null`).
        Default: 0
      - category_name?: string | null
        Name of the CIF category to read annotation from. If `null`, the first category in the block is used.
        Default: null
      - field_name?: string
        Name of the column in CIF or field name (key) in JSON that contains the component identifier.
        Default: "component"
      - field_remapping?: { [K in string]: (string | null) }
        Optional remapping of annotation field names `{ standardName1: actualName1, ... }`. Use `{ "label_asym_id": "X" }` to load actual field "X" as "label_asym_id". Use `{ "label_asym_id": null }` to ignore actual field "label_asym_id". Fields not mentioned here are mapped implicitely (i.e. actual name = standard name).
        Default: {}
      - field_values?: Array<string> | null
        List of component identifiers (i.e. values in the field given by `field_name`) which should be included in this component. If `null`, component identifiers are ignored (all annotation rows are included), and `field_name` field can be dropped from the annotation.
        Default: null
  - representation
    This node instructs to create a visual representation of a component.
    Parent: component or component_from_uri or component_from_source
    Params:
      - type: cartoon | ball_and_stick | spacefill | carbohydrate | surface
        Representation type
        [This parameter determines the rest of parameters]
        Case type: "cartoon":
          - size_factor?: number
            Scales the corresponding visuals.
            Default: 1
          - tubular_helices?: boolean
            Simplify corkscrew helices to tubes.
            Default: false
        Case type: "ball_and_stick":
          - size_factor?: number
            Scales the corresponding visuals.
            Default: 1
          - ignore_hydrogens?: boolean
            Controls whether hydrogen atoms are drawn.
            Default: false
        Case type: "spacefill":
          - size_factor?: number
            Scales the corresponding visuals.
            Default: 1
          - ignore_hydrogens?: boolean
            Controls whether hydrogen atoms are drawn.
            Default: false
        Case type: "carbohydrate":
          - size_factor?: number
            Scales the corresponding visuals.
            Default: 1
        Case type: "surface":
          - size_factor?: number
            Scales the corresponding visuals.
            Default: 1
          - ignore_hydrogens?: boolean
            Controls whether hydrogen atoms are drawn.
            Default: false
  - volume
    This node instructs to create a volume from a parsed data resource. "Volume" refers to an internal representation of volumetric data without any visual representation.
    Parent: parse
    Params:
      - channel_id?: string | null
        Channel identifier (only applies when the input data contain multiple channels).
        Default: null
  - volume_representation
    This node instructs to create a visual representation of a volume.
    Parent: volume
    Params:
      - type: isosurface
        Representation type
        [This parameter determines the rest of parameters]
        Case type: "isosurface":
          - relative_isovalue?: number | null
            Relative isovalue.
            Default: null
          - absolute_isovalue?: number | null
            Absolute isovalue. Overrides `relative_isovalue`.
            Default: null
          - show_wireframe?: boolean
            Show mesh wireframe. Defaults to false.
            Default: false
          - show_faces?: boolean
            Show mesh faces. Defaults to true.
            Default: true
  - color
    This node instructs to apply color to a visual representation.
    Parent: representation or volume_representation
    Params:
      - color?: ColorName | HexColor
        Color to apply to the representation. Can be either an X11 color name (e.g. `"red"`) or a hexadecimal code (e.g. `"#FF0011"`).
        Default: "white"
      - selector?: ("all" | "polymer" | "protein" | "nucleic" | "branched" | "ligand" | "ion" | "water" | "coarse") | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }>
        Defines to what part of the representation this color should be applied.
        Default: "all"
  - color_from_uri
    This node instructs to apply colors to a visual representation. The colors are defined by an external annotation resource.
    Parent: representation
    Params:
      - uri: string
        URL of the annotation resource.
      - format: "cif" | "bcif" | "json"
        Format of the annotation resource.
      - schema: "whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"
        Annotation schema defines what fields in the annotation will be taken into account.
      - block_header?: string | null
        Header of the CIF block to read annotation from (only applies when `format` is `"cif"` or `"bcif"`). If `null`, block is selected based on `block_index`.
        Default: null
      - block_index?: Integer
        0-based index of the CIF block to read annotation from (only applies when `format` is `"cif"` or `"bcif"` and `block_header` is `null`).
        Default: 0
      - category_name?: string | null
        Name of the CIF category to read annotation from (only applies when `format` is `"cif"` or `"bcif"`). If `null`, the first category in the block is used.
        Default: null
      - field_name?: string
        Name of the column in CIF or field name (key) in JSON that contains the color.
        Default: "color"
      - field_remapping?: { [K in string]: (string | null) }
        Optional remapping of annotation field names `{ standardName1: actualName1, ... }`. Use `{ "label_asym_id": "X" }` to load actual field "X" as "label_asym_id". Use `{ "label_asym_id": null }` to ignore actual field "label_asym_id". Fields not mentioned here are mapped implicitely (i.e. actual name = standard name).
        Default: {}
      - palette?: { kind: "categorical", colors?: (("Reds" | "Oranges" | "Greens" | "Blues" | "Purples" | "Greys" | "OrRd" | "BuGn" | "PuBuGn" | "GnBu" | "PuBu" | "BuPu" | "RdPu" | "PuRd" | "YlOrRd" | "YlOrBr" | "YlGn" | "YlGnBu" | "Magma" | "Inferno" | "Plasma" | "Viridis" | "Cividis" | "Turbo" | "Warm" | "Cool" | "CubehelixDefault" | "Rainbow" | "Sinebow" | "RdBu" | "RdGy" | "PiYG" | "BrBG" | "PRGn" | "PuOr" | "RdYlGn" | "RdYlBu" | "Spectral" | "Category10" | "Observable10" | "Tableau10" | "Set1" | "Set2" | "Set3" | "Pastel1" | "Pastel2" | "Dark2" | "Paired" | "Accent" | "Chainbow") | ("ElementSymbol" | "ResidueName" | "ResidueProperties") | Array<(ColorName | HexColor)> | { [K in string]: (ColorName | HexColor) }), missing_color?: (ColorName | HexColor | null), repeat_color_list?: boolean, sort?: ("none" | "lexical" | "numeric"), sort_direction?: ("ascending" | "descending") } | { kind: "discrete", colors?: (("Reds" | "Oranges" | "Greens" | "Blues" | "Purples" | "Greys" | "OrRd" | "BuGn" | "PuBuGn" | "GnBu" | "PuBu" | "BuPu" | "RdPu" | "PuRd" | "YlOrRd" | "YlOrBr" | "YlGn" | "YlGnBu" | "Magma" | "Inferno" | "Plasma" | "Viridis" | "Cividis" | "Turbo" | "Warm" | "Cool" | "CubehelixDefault" | "Rainbow" | "Sinebow" | "RdBu" | "RdGy" | "PiYG" | "BrBG" | "PRGn" | "PuOr" | "RdYlGn" | "RdYlBu" | "Spectral" | "Category10" | "Observable10" | "Tableau10" | "Set1" | "Set2" | "Set3" | "Pastel1" | "Pastel2" | "Dark2" | "Paired" | "Accent" | "Chainbow") | Array<(ColorName | HexColor)> | Array<[(ColorName | HexColor), number]> | Array<[(ColorName | HexColor | null), (number | null), (number | null)]>), reverse?: boolean, mode?: ("normalized" | "absolute"), value_domain?: [(number | null), (number | null)] } | { kind: "continuous", colors?: (("Reds" | "Oranges" | "Greens" | "Blues" | "Purples" | "Greys" | "OrRd" | "BuGn" | "PuBuGn" | "GnBu" | "PuBu" | "BuPu" | "RdPu" | "PuRd" | "YlOrRd" | "YlOrBr" | "YlGn" | "YlGnBu" | "Magma" | "Inferno" | "Plasma" | "Viridis" | "Cividis" | "Turbo" | "Warm" | "Cool" | "CubehelixDefault" | "Rainbow" | "Sinebow" | "RdBu" | "RdGy" | "PiYG" | "BrBG" | "PRGn" | "PuOr" | "RdYlGn" | "RdYlBu" | "Spectral" | "Category10" | "Observable10" | "Tableau10" | "Set1" | "Set2" | "Set3" | "Pastel1" | "Pastel2" | "Dark2" | "Paired" | "Accent" | "Chainbow") | Array<(ColorName | HexColor)> | Array<[(ColorName | HexColor), number]>), reverse?: boolean, mode?: ("normalized" | "absolute"), value_domain?: [(number | null), (number | null)], underflow_color?: ("auto" | ColorName | HexColor | null), overflow_color?: ("auto" | ColorName | HexColor | null) } | null
        Customize mapping of annotation values to colors.
        Default: null
  - color_from_source
    This node instructs to apply colors to a visual representation. The colors are defined by an annotation resource included in the same file this structure was loaded from. Only applicable if the structure was loaded from an mmCIF or BinaryCIF file.
    Parent: representation
    Params:
      - schema: "whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"
        Annotation schema defines what fields in the annotation will be taken into account.
      - block_header?: string | null
        Header of the CIF block to read annotation from. If `null`, block is selected based on `block_index`.
        Default: null
      - block_index?: Integer
        0-based index of the CIF block to read annotation from (only applies when `block_header` is `null`).
        Default: 0
      - category_name?: string | null
        Name of the CIF category to read annotation from. If `null`, the first category in the block is used.
        Default: null
      - field_name?: string
        Name of the column in CIF or field name (key) in JSON that contains the color.
        Default: "color"
      - field_remapping?: { [K in string]: (string | null) }
        Optional remapping of annotation field names `{ standardName1: actualName1, ... }`. Use `{ "label_asym_id": "X" }` to load actual field "X" as "label_asym_id". Use `{ "label_asym_id": null }` to ignore actual field "label_asym_id". Fields not mentioned here are mapped implicitely (i.e. actual name = standard name).
        Default: {}
      - palette?: { kind: "categorical", colors?: (("Reds" | "Oranges" | "Greens" | "Blues" | "Purples" | "Greys" | "OrRd" | "BuGn" | "PuBuGn" | "GnBu" | "PuBu" | "BuPu" | "RdPu" | "PuRd" | "YlOrRd" | "YlOrBr" | "YlGn" | "YlGnBu" | "Magma" | "Inferno" | "Plasma" | "Viridis" | "Cividis" | "Turbo" | "Warm" | "Cool" | "CubehelixDefault" | "Rainbow" | "Sinebow" | "RdBu" | "RdGy" | "PiYG" | "BrBG" | "PRGn" | "PuOr" | "RdYlGn" | "RdYlBu" | "Spectral" | "Category10" | "Observable10" | "Tableau10" | "Set1" | "Set2" | "Set3" | "Pastel1" | "Pastel2" | "Dark2" | "Paired" | "Accent" | "Chainbow") | ("ElementSymbol" | "ResidueName" | "ResidueProperties") | Array<(ColorName | HexColor)> | { [K in string]: (ColorName | HexColor) }), missing_color?: (ColorName | HexColor | null), repeat_color_list?: boolean, sort?: ("none" | "lexical" | "numeric"), sort_direction?: ("ascending" | "descending") } | { kind: "discrete", colors?: (("Reds" | "Oranges" | "Greens" | "Blues" | "Purples" | "Greys" | "OrRd" | "BuGn" | "PuBuGn" | "GnBu" | "PuBu" | "BuPu" | "RdPu" | "PuRd" | "YlOrRd" | "YlOrBr" | "YlGn" | "YlGnBu" | "Magma" | "Inferno" | "Plasma" | "Viridis" | "Cividis" | "Turbo" | "Warm" | "Cool" | "CubehelixDefault" | "Rainbow" | "Sinebow" | "RdBu" | "RdGy" | "PiYG" | "BrBG" | "PRGn" | "PuOr" | "RdYlGn" | "RdYlBu" | "Spectral" | "Category10" | "Observable10" | "Tableau10" | "Set1" | "Set2" | "Set3" | "Pastel1" | "Pastel2" | "Dark2" | "Paired" | "Accent" | "Chainbow") | Array<(ColorName | HexColor)> | Array<[(ColorName | HexColor), number]> | Array<[(ColorName | HexColor | null), (number | null), (number | null)]>), reverse?: boolean, mode?: ("normalized" | "absolute"), value_domain?: [(number | null), (number | null)] } | { kind: "continuous", colors?: (("Reds" | "Oranges" | "Greens" | "Blues" | "Purples" | "Greys" | "OrRd" | "BuGn" | "PuBuGn" | "GnBu" | "PuBu" | "BuPu" | "RdPu" | "PuRd" | "YlOrRd" | "YlOrBr" | "YlGn" | "YlGnBu" | "Magma" | "Inferno" | "Plasma" | "Viridis" | "Cividis" | "Turbo" | "Warm" | "Cool" | "CubehelixDefault" | "Rainbow" | "Sinebow" | "RdBu" | "RdGy" | "PiYG" | "BrBG" | "PRGn" | "PuOr" | "RdYlGn" | "RdYlBu" | "Spectral" | "Category10" | "Observable10" | "Tableau10" | "Set1" | "Set2" | "Set3" | "Pastel1" | "Pastel2" | "Dark2" | "Paired" | "Accent" | "Chainbow") | Array<(ColorName | HexColor)> | Array<[(ColorName | HexColor), number]>), reverse?: boolean, mode?: ("normalized" | "absolute"), value_domain?: [(number | null), (number | null)], underflow_color?: ("auto" | ColorName | HexColor | null), overflow_color?: ("auto" | ColorName | HexColor | null) } | null
        Customize mapping of annotation values to colors.
        Default: null
  - opacity
    This node instructs to apply opacity/transparency to a visual representation.
    Parent: representation or volume_representation
    Params:
      - opacity: number
        Opacity of a representation. 0.0: fully transparent, 1.0: fully opaque.
  - label
    This node instructs to add a label (textual visual representation) to a component.
    Parent: component or component_from_uri or component_from_source
    Params:
      - text: string
        Content of the shown label.
  - label_from_uri
    This node instructs to add labels (textual visual representations) to parts of a structure. The labels are defined by an external annotation resource.
    Parent: structure
    Params:
      - uri: string
        URL of the annotation resource.
      - format: "cif" | "bcif" | "json"
        Format of the annotation resource.
      - schema: "whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"
        Annotation schema defines what fields in the annotation will be taken into account.
      - block_header?: string | null
        Header of the CIF block to read annotation from (only applies when `format` is `"cif"` or `"bcif"`). If `null`, block is selected based on `block_index`.
        Default: null
      - block_index?: Integer
        0-based index of the CIF block to read annotation from (only applies when `format` is `"cif"` or `"bcif"` and `block_header` is `null`).
        Default: 0
      - category_name?: string | null
        Name of the CIF category to read annotation from (only applies when `format` is `"cif"` or `"bcif"`). If `null`, the first category in the block is used.
        Default: null
      - field_name?: string
        Name of the column in CIF or field name (key) in JSON that contains the label text.
        Default: "label"
      - field_remapping?: { [K in string]: (string | null) }
        Optional remapping of annotation field names `{ standardName1: actualName1, ... }`. Use `{ "label_asym_id": "X" }` to load actual field "X" as "label_asym_id". Use `{ "label_asym_id": null }` to ignore actual field "label_asym_id". Fields not mentioned here are mapped implicitely (i.e. actual name = standard name).
        Default: {}
  - label_from_source
    This node instructs to add labels (textual visual representations) to parts of a structure. The labels are defined by an annotation resource included in the same file this structure was loaded from. Only applicable if the structure was loaded from an mmCIF or BinaryCIF file.
    Parent: structure
    Params:
      - schema: "whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"
        Annotation schema defines what fields in the annotation will be taken into account.
      - block_header?: string | null
        Header of the CIF block to read annotation from. If `null`, block is selected based on `block_index`.
        Default: null
      - block_index?: Integer
        0-based index of the CIF block to read annotation from (only applies when `block_header` is `null`).
        Default: 0
      - category_name?: string | null
        Name of the CIF category to read annotation from. If `null`, the first category in the block is used.
        Default: null
      - field_name?: string
        Name of the column in CIF or field name (key) in JSON that contains the label text.
        Default: "label"
      - field_remapping?: { [K in string]: (string | null) }
        Optional remapping of annotation field names `{ standardName1: actualName1, ... }`. Use `{ "label_asym_id": "X" }` to load actual field "X" as "label_asym_id". Use `{ "label_asym_id": null }` to ignore actual field "label_asym_id". Fields not mentioned here are mapped implicitely (i.e. actual name = standard name).
        Default: {}
  - tooltip
    This node instructs to add a tooltip to a component. "Tooltip" is a text which is not a part of the visualization but should be presented to the users when they interact with the component (typically, the tooltip will be shown somewhere on the screen when the user hovers over a visual representation of the component).
    Parent: component or component_from_uri or component_from_source
    Params:
      - text: string
        Content of the shown tooltip.
  - tooltip_from_uri
    This node instructs to add tooltips to parts of a structure. The tooltips are defined by an external annotation resource.
    Parent: structure
    Params:
      - uri: string
        URL of the annotation resource.
      - format: "cif" | "bcif" | "json"
        Format of the annotation resource.
      - schema: "whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"
        Annotation schema defines what fields in the annotation will be taken into account.
      - block_header?: string | null
        Header of the CIF block to read annotation from (only applies when `format` is `"cif"` or `"bcif"`). If `null`, block is selected based on `block_index`.
        Default: null
      - block_index?: Integer
        0-based index of the CIF block to read annotation from (only applies when `format` is `"cif"` or `"bcif"` and `block_header` is `null`).
        Default: 0
      - category_name?: string | null
        Name of the CIF category to read annotation from (only applies when `format` is `"cif"` or `"bcif"`). If `null`, the first category in the block is used.
        Default: null
      - field_name?: string
        Name of the column in CIF or field name (key) in JSON that contains the tooltip text.
        Default: "tooltip"
      - field_remapping?: { [K in string]: (string | null) }
        Optional remapping of annotation field names `{ standardName1: actualName1, ... }`. Use `{ "label_asym_id": "X" }` to load actual field "X" as "label_asym_id". Use `{ "label_asym_id": null }` to ignore actual field "label_asym_id". Fields not mentioned here are mapped implicitely (i.e. actual name = standard name).
        Default: {}
  - tooltip_from_source
    This node instructs to add tooltips to parts of a structure. The tooltips are defined by an annotation resource included in the same file this structure was loaded from. Only applicable if the structure was loaded from an mmCIF or BinaryCIF file.
    Parent: structure
    Params:
      - schema: "whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"
        Annotation schema defines what fields in the annotation will be taken into account.
      - block_header?: string | null
        Header of the CIF block to read annotation from. If `null`, block is selected based on `block_index`.
        Default: null
      - block_index?: Integer
        0-based index of the CIF block to read annotation from (only applies when `block_header` is `null`).
        Default: 0
      - category_name?: string | null
        Name of the CIF category to read annotation from. If `null`, the first category in the block is used.
        Default: null
      - field_name?: string
        Name of the column in CIF or field name (key) in JSON that contains the tooltip text.
        Default: "tooltip"
      - field_remapping?: { [K in string]: (string | null) }
        Optional remapping of annotation field names `{ standardName1: actualName1, ... }`. Use `{ "label_asym_id": "X" }` to load actual field "X" as "label_asym_id". Use `{ "label_asym_id": null }` to ignore actual field "label_asym_id". Fields not mentioned here are mapped implicitely (i.e. actual name = standard name).
        Default: {}
  - focus
    This node instructs to set the camera focus to a component (zoom in).
    Parent: root or component or component_from_uri or component_from_source or primitives or primitives_from_uri or volume or volume_representation
    Params:
      - direction?: [number, number, number]
        Vector describing the direction of the view (camera position -> focused target).
        Default: [0, 0, -1]
      - up?: [number, number, number]
        Vector which will be aligned with the screen Y axis.
        Default: [0, 1, 0]
      - radius?: number | null
        Radius of the focused sphere (overrides `radius_factor` and `radius_extra`).
        Default: null
      - radius_factor?: number
        Radius of the focused sphere relative to the radius of parent component (default: 1). Focused radius = component_radius * radius_factor + radius_extent.
        Default: 1
      - radius_extent?: number
        Addition to the radius of the focused sphere, if computed from the radius of parent component (default: 0). Focused radius = component_radius * radius_factor + radius_extent.
        Default: 0
  - camera
    This node instructs to set the camera position and orientation.
    Parent: root
    Params:
      - target: [number, number, number]
        Coordinates of the point in space at which the camera is pointing.
      - position: [number, number, number]
        Coordinates of the camera.
      - up?: [number, number, number]
        Vector which will be aligned with the screen Y axis.
        Default: [0, 1, 0]
  - canvas
    This node sets canvas properties.
    Parent: root
    Params:
      - background_color: ColorName | HexColor
        Color of the canvas background. Can be either an X11 color name (e.g. `"red"`) or a hexadecimal code (e.g. `"#FF0011"`).
  - primitives
    This node groups a list of geometrical primitives
    Parent: structure or root
    Params:
      - color?: ColorName | HexColor
        Default color for primitives in this group.
        Default: "white"
      - label_color?: ColorName | HexColor
        Default label color for primitives in this group.
        Default: "white"
      - tooltip?: string | null
        Default tooltip for primitives in this group.
        Default: null
      - opacity?: number
        Opacity of primitive geometry in this group.
        Default: 1
      - label_opacity?: number
        Opacity of primitive labels in this group.
        Default: 1
      - instances?: Array<Array<number>> | null
        Instances of this primitive group defined as 4x4 column major (j * 4 + i indexing) transformation matrices.
        Default: null
  - primitives_from_uri
    This node loads a list of primitives from URI
    Parent: structure or root
    Params:
      - uri: string
        Location of the resource.
      - format: "mvs-node-json"
        Format of the data.
      - references?: Array<string>
        List of nodes the data are referencing.
        Default: []
  - primitive
    This node represents a geometrical primitive
    Parent: primitives
    Params:
      - kind: mesh | lines | tube | arrow | distance_measurement | angle_measurement | label | ellipse | ellipsoid | box
        Kind of geometrical primitive
        [This parameter determines the rest of parameters]
        Case kind: "mesh":
          - vertices: Array<number>
            3*n_vertices length array of floats with vertex position (x1, y1, z1, ...).
          - indices: Array<Integer>
            3*n_triangles length array of indices into vertices that form triangles (t1_1, t1_2, t1_3, ...).
          - triangle_groups?: Array<Integer> | null
            Assign a number to each triangle to group them. If not specified, each triangle is considered a separate group (triangle i = group i).
            Default: null
          - group_colors?: { [K in Integer]: (ColorName | HexColor) }
            Assign a color to each group. Where not assigned, uses `color`.
            Default: {}
          - group_tooltips?: { [K in Integer]: string }
            Assign a tooltip to each group. Where not assigned, uses `tooltip`.
            Default: {}
          - color?: ColorName | HexColor | null
            Color of the triangles and wireframe. Can be overwritten by `group_colors`. If not specified, uses the parent primitives group `color`.
            Default: null
          - tooltip?: string | null
            Tooltip shown when hovering over the mesh. Can be overwritten by `group_tooltips`. If not specified, uses the parent primitives group `tooltip`.
            Default: null
          - show_triangles?: boolean
            Determine whether to render triangles of the mesh.
            Default: true
          - show_wireframe?: boolean
            Determine whether to render wireframe of the mesh.
            Default: false
          - wireframe_width?: number
            Wireframe line width (in screen-space units).
            Default: 1
          - wireframe_color?: ColorName | HexColor | null
            Wireframe color. If not specified, uses `group_colors`.
            Default: null
        Case kind: "lines":
          - vertices: Array<number>
            3*n_vertices length array of floats with vertex position (x1, y1, z1, ...).
          - indices: Array<Integer>
            2*n_lines length array of indices into vertices that form lines (l1_1, l1_2, ...).
          - line_groups?: Array<Integer> | null
            Assign a number to each triangle to group them. If not specified, each line is considered a separate group (line i = group i).
            Default: null
          - group_colors?: { [K in Integer]: (ColorName | HexColor) }
            Assign a color to each group. Where not assigned, uses `color`.
            Default: {}
          - group_tooltips?: { [K in Integer]: string }
            Assign a tooltip to each group. Where not assigned, uses `tooltip`.
            Default: {}
          - group_widths?: { [K in Integer]: number }
            Assign a line width to each group. Where not assigned, uses `width`.
            Default: {}
          - color?: ColorName | HexColor | null
            Color of the lines. Can be overwritten by `group_colors`. If not specified, uses the parent primitives group `color`.
            Default: null
          - tooltip?: string | null
            Tooltip shown when hovering over the lines. Can be overwritten by `group_tooltips`. If not specified, uses the parent primitives group `tooltip`.
            Default: null
          - width?: number
            Line width (in screen-space units). Can be overwritten by `group_widths`.
            Default: 1
        Case kind: "tube":
          - start: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> }
            Start point of the tube.
          - end: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> }
            End point of the tube.
          - radius?: number
            Tube radius (in Angstroms).
            Default: 0.05
          - dash_length?: number | null
            Length of each dash and gap between dashes. If not specified (null), draw full line.
            Default: null
          - color?: ColorName | HexColor | null
            Color of the tube. If not specified, uses the parent primitives group `color`.
            Default: null
          - tooltip?: string | null
            Tooltip to show when hovering over the tube. If not specified, uses the parent primitives group `tooltip`.
            Default: null
        Case kind: "arrow":
          - start: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> }
            Start point of the arrow.
          - end?: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> } | null
            End point of the arrow.
            Default: null
          - direction?: [number, number, number] | null
            If specified, the endpoint is computed as start + direction.
            Default: null
          - length?: number | null
            Length of the arrow. If unset, the distance between start and end is used.
            Default: null
          - show_start_cap?: boolean
            Draw a cap at the start of the arrow.
            Default: false
          - start_cap_length?: number | null
            Length of the start cap. If not provided, will be 2 * start_cap_radius.
            Default: null
          - start_cap_radius?: number | null
            Radius of the start cap. If not provided, will be 2 * tube_radius.
            Default: null
          - show_end_cap?: boolean
            Draw a cap at the end of the arrow.
            Default: false
          - end_cap_length?: number | null
            Length of the end cap. If not provided, will be 2 * end_cap_radius.
            Default: null
          - end_cap_radius?: number | null
            Radius of the end cap. If not provided, will be 2 * tube_radius.
            Default: null
          - show_tube?: boolean
            Draw a tube connecting the start and end points.
            Default: true
          - tube_radius?: number
            Tube radius (in Angstroms).
            Default: 0.05
          - tube_dash_length?: number | null
            Length of each dash and gap between dashes. If not specified (null), draw full line.
            Default: null
          - color?: ColorName | HexColor | null
            Color of the tube. If not specified, uses the parent primitives group `color`.
            Default: null
          - tooltip?: string | null
            Tooltip to show when hovering over the arrow. If not specified, uses the parent primitives group `tooltip`.
            Default: null
        Case kind: "distance_measurement":
          - start: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> }
            Start point of the tube.
          - end: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> }
            End point of the tube.
          - radius?: number
            Tube radius (in Angstroms).
            Default: 0.05
          - dash_length?: number | null
            Length of each dash and gap between dashes. If not specified (null), draw full line.
            Default: null
          - color?: ColorName | HexColor | null
            Color of the tube. If not specified, uses the parent primitives group `color`.
            Default: null
          - label_template?: string
            Template used to construct the label. Use {{distance}} as placeholder for the distance.
            Default: "{{distance}}"
          - label_size?: number | null
            Size of the label (text height in Angstroms). If not specified, size will be relative to the distance (see label_auto_size_scale, label_auto_size_min).
            Default: null
          - label_auto_size_scale?: number
            Scaling factor for relative size.
            Default: 0.1
          - label_auto_size_min?: number
            Minimum size for relative size.
            Default: 0
          - label_color?: ColorName | HexColor | null
            Color of the label. If not specified, uses the parent primitives group `label_color`.
            Default: null
        Case kind: "angle_measurement":
          - a: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> }
            Point A.
          - b: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> }
            Point B.
          - c: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> }
            Point C.
          - label_template?: string
            Template used to construct the label. Use {{angle}} as placeholder for the angle in radians.
            Default: "{{angle}}"
          - label_size?: number | null
            Size of the label (text height in Angstroms). If not specified, size will be relative to the distance (see label_auto_size_scale, label_auto_size_min).
            Default: null
          - label_auto_size_scale?: number
            Scaling factor for relative size.
            Default: 0.33
          - label_auto_size_min?: number
            Minimum size for relative size.
            Default: 0
          - label_color?: ColorName | HexColor | null
            Color of the label. If not specified, uses the parent primitives group `label_color`.
            Default: null
          - show_vector?: boolean
            Draw vectors between (a, b) and (b, c).
            Default: true
          - vector_color?: ColorName | HexColor | null
            Color of the vectors.
            Default: null
          - vector_radius?: number
            Radius of the vectors.
            Default: 0.05
          - show_section?: boolean
            Draw a filled circle section representing the angle.
            Default: true
          - section_color?: ColorName | HexColor | null
            Color of the angle section. If not specified, the primitives group color is used.
            Default: null
          - section_radius?: number | null
            Radius of the angle section. In angstroms.
            Default: null
          - section_radius_scale?: number
            Factor to scale the radius of the angle section. Ignored if section_radius is set.
            Default: 0.33
        Case kind: "label":
          - position: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> }
            Position of this label.
          - text: string
            The label.
          - label_size?: number
            Size of the label (text height in Angstroms).
            Default: 1
          - label_color?: ColorName | HexColor | null
            Color of the label. If not specified, uses the parent primitives group `label_color`.
            Default: null
          - label_offset?: number
            Camera-facing offset to prevent overlap with geometry.
            Default: 0
        Case kind: "ellipse":
          - color?: ColorName | HexColor | null
            Color of the ellipse. If not specified, uses the parent primitives group `color`.
            Default: null
          - as_circle?: boolean
            If true, ignores radius_minor/magnitude of the minor axis.
            Default: false
          - center: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> }
            The center of the ellipse.
          - major_axis?: [number, number, number] | null
            Major axis of this ellipse.
            Default: null
          - minor_axis?: [number, number, number] | null
            Minor axis of this ellipse.
            Default: null
          - major_axis_endpoint?: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> } | null
            Major axis endpoint. If specified, overrides major axis to be major_axis_endpoint - center.
            Default: null
          - minor_axis_endpoint?: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> } | null
            Minor axis endpoint. If specified, overrides minor axis to be minor_axis_endpoint - center.
            Default: null
          - radius_major?: number | null
            Radius of the major axis. If unset, the length of the major axis is used.
            Default: null
          - radius_minor?: number | null
            Radius of the minor axis. If unset, the length of the minor axis is used.
            Default: null
          - theta_start?: number
            Start of the arc. In radians
            Default: 0
          - theta_end?: number
            End of the arc. In radians
            Default: 6.283185307179586
          - tooltip?: string | null
            Tooltip to show when hovering over the tube. If not specified, uses the parent primitives group `tooltip`.
            Default: null
        Case kind: "ellipsoid":
          - color?: ColorName | HexColor | null
            Color of the ellipsoid. If not specified, uses the parent primitives group `color`.
            Default: null
          - center: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> }
            The center of the ellipsoid.
          - major_axis?: [number, number, number] | null
            Major axis of this ellipsoid.
            Default: null
          - minor_axis?: [number, number, number] | null
            Minor axis of this ellipsoid.
            Default: null
          - major_axis_endpoint?: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> } | null
            Major axis endpoint. If specified, overrides major axis to be major_axis_endpoint - center.
            Default: null
          - minor_axis_endpoint?: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> } | null
            Minor axis endpoint. If specified, overrides minor axis to be minor_axis_endpoint - center.
            Default: null
          - radius?: [number, number, number] | number | null
            Radii of the ellipsoid along each axis.
            Default: null
          - radius_extent?: [number, number, number] | number | null
            Added to the radii of the ellipsoid along each axis.
            Default: null
          - tooltip?: string | null
            Tooltip to show when hovering over the tube. If not specified, uses the parent primitives group `tooltip`.
            Default: null
        Case kind: "box":
          - center: [number, number, number] | { label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer } | { structure_ref?: string, expression_schema?: ("whole_structure" | "entity" | "chain" | "auth_chain" | "residue" | "auth_residue" | "residue_range" | "auth_residue_range" | "atom" | "auth_atom" | "all_atomic"), expressions?: Array<{ label_entity_id?: string, label_asym_id?: string, auth_asym_id?: string, label_seq_id?: Integer, auth_seq_id?: Integer, pdbx_PDB_ins_code?: string, beg_label_seq_id?: Integer, end_label_seq_id?: Integer, beg_auth_seq_id?: Integer, end_auth_seq_id?: Integer, label_comp_id?: string, auth_comp_id?: string, label_atom_id?: string, auth_atom_id?: string, type_symbol?: string, atom_id?: Integer, atom_index?: Integer }> }
            The center of the box.
          - extent?: [number, number, number] | null
            The width, the height, and the depth of the box. Added to the bounding box determined by the center.
            Default: null
          - show_faces?: boolean
            Determine whether to render the faces of the box.
            Default: true
          - face_color?: ColorName | HexColor | null
            Color of the box faces.
            Default: null
          - show_edges?: boolean
            Determine whether to render the edges of the box.
            Default: false
          - edge_radius?: number
            Radius of the box edges. In angstroms.
            Default: 0.1
          - edge_color?: ColorName | HexColor | null
            Color of the edges.
            Default: null
          - tooltip?: string | null
            Tooltip to show when hovering over the tube. If not specified, uses the parent primitives group `tooltip`.
            Default: null
